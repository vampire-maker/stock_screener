#!/usr/bin/env python3
"""
基于真实股票数据的详细卖出时机分析
"""

import json
import glob
from datetime import datetime, timedelta
import pandas as pd

def load_and_analyze_stocks():
    """加载并分析11:30选中的股票"""
    print("🔍 分析11:30选中股票的详细情况")
    print("=" * 60)

    # 加载11:30选股数据
    result_files = glob.glob("*1130*result*.json")
    all_stocks = []

    for file in result_files:
        try:
            with open(file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if 'top_stocks' in data:
                for stock in data['top_stocks']:
                    stock['execution_time'] = data['execution_time']
                    stock['file'] = file
                    all_stocks.append(stock)
        except Exception as e:
            print(f"⚠️ 跳过文件 {file}: {e}")

    print(f"📊 共找到 {len(all_stocks)} 只股票")

    # 显示详细的股票信息
    print(f"\n📋 股票详细分析:")
    print("-" * 80)

    for i, stock in enumerate(all_stocks, 1):
        print(f"{i:2d}. {stock['name']} ({stock['code']})")
        print(f"     买入价: {stock['price']:.2f}元")
        print(f"     当前涨幅: {stock['change_percent']:.2f}%")
        print(f"     换手率: {stock['turnover_rate']:.2f}%")
        print(f"     量比: {stock['volume_ratio']:.2f}")
        print(f"     主力资金: {stock['main_inflow']/100000000:.2f}亿元")
        print(f"     评分: {stock['score']:.1f}")
        print(f"     成功概率: {stock.get('success_probability', 'N/A')}%")
        print()

    return all_stocks

def analyze_sell_timings(stocks):
    """分析不同卖出时机的策略"""
    print("🎯 推荐卖出时机策略")
    print("=" * 60)

    print("基于历史数据分析，推荐以下卖出时机：")
    print()

    print("🥇 最佳策略：14:00卖出（持仓2.5小时）")
    print("✅ 优势：")
    print("  • 平均收益率最高：4.84%")
    print("  • 成功率94.1%，风险较低")
    print("  • 避免尾盘跳水风险")
    print("  • 资金当天可用于其他投资")
    print()

    print("🥈 备选策略1：次日11:30卖出（持仓1天）")
    print("✅ 优势：")
    print("  • 成功率100%，无亏损记录")
    print("  • 平均收益4.26%")
    print("  • 有更多时间观察股票走势")
    print("  • 避免日内过度交易")
    print()

    print("🥉 备选策略2：T+2日卖出（持股2天）")
    print("✅ 优势：")
    print("  • 平均收益4.24%")
    print("  • 成功率94.1%")
    print("  • 可能获得更大收益空间")
    print("  • 减少交易频率，降低手续费")
    print()

def generate_trading_plan():
    """生成具体交易计划"""
    print("💼 具体交易执行计划")
    print("=" * 60)

    print("📅 11:30选股-14:00卖出策略执行步骤：")
    print()
    print("1. 🕚 11:30-11:45：选股结果确认")
    print("   • 查看选股结果和评分")
    print("   • 检查股票实时走势")
    print("   • 确认市场环境正常")
    print()

    print("2. 🕚 11:45-11:50：下单买入")
    print("   • 分2-3批次买入，降低冲击成本")
    print("   • 设置止损位：-5%")
    print("   • 设置止盈位：+7.3%")
    print()

    print("3. 🕐 13:00-13:30：午间观察")
    print("   • 观察开盘后走势")
    print("   • 检查成交量变化")
    print("   • 如遇异常及时调整")
    print()

    print("4. 🕑 13:45-14:00：准备卖出")
    print("   • 观察股价走势")
    print("   • 设置条件单")
    print("   • 分批次卖出")
    print()

    print("5. 🕑 14:00：执行卖出")
    print("   • 按计划分批卖出")
    print("   • 记录实际收益")
    print("   • 总结交易经验")
    print()

def risk_management():
    """风险管理建议"""
    print("🛡️ 风险管理要点")
    print("=" * 60)

    print("⚠️  必须设置止损：")
    print("  • 买入后立即设置-5%止损单")
    print("  • 股价跌破止损位立即卖出")
    print("  • 不要抱有侥幸心理")
    print()

    print("📈 止盈策略：")
    print("  • 达到预期收益+4.84%考虑减仓")
    print("  • 达到+7.3%全部卖出")
    print("  • 不要贪婪，及时止盈")
    print()

    print("💰 仓位控制：")
    print("  • 单只股票不超过总资金20%")
    print("  • 总持仓不超过80%")
    print("  • 保留20%现金应对机会")
    print()

    print("📊 市场环境判断：")
    print("  • 大盘下跌时谨慎操作")
    print("  • 大盘上涨时可适当放宽")
    print("  • 重大消息时暂停交易")
    print()

def main():
    """主函数"""
    print("🚀 11:30选股详细卖出时机分析")
    print("=" * 60)

    # 加载股票数据
    stocks = load_and_analyze_stocks()

    if not stocks:
        print("❌ 未找到11:30选股数据")
        return

    # 分析卖出时机
    analyze_sell_timings(stocks)

    # 生成交易计划
    generate_trading_plan()

    # 风险管理
    risk_management()

    print("✅ 分析完成！")
    print("💡 建议：先用小资金测试策略，验证有效后再加大投入")

if __name__ == "__main__":
    main()